﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Job
{
    public partial class HomeForm : Form
    {
     
        public HomeForm()
        {
            InitializeComponent();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void HomeForm_Load(object sender, EventArgs e)
        {

        }

        private void viewSurveysToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form Surveyform = new SurveyView();
            Surveyform.ShowDialog();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            openFileDialog1.ShowDialog();
        }

        private void textBox100_TextChanged(object sender, EventArgs e)
        {

        }

        private void viewJobCardsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form JobCardform = new JobCardView();
            JobCardform.ShowDialog();
            this.Close();
        }

        private void surveysToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void viewSMMESToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void updateJobCardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form jobCardUpdate = new Job_Update();
            jobCardUpdate.ShowDialog();
            this.Close();
        }
    }
}
