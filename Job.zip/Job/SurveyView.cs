﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Job
{
    public partial class SurveyView : Form
    {
        public SurveyView()
        {
            InitializeComponent();
        }

        private void label91_Click(object sender, EventArgs e)
        {

        }

        private void groupBox23_Enter(object sender, EventArgs e)
        {

        }

        private void viewSurveysToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void captureSurveyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form CaptureStylesheetform = new HomeForm();
            CaptureStylesheetform.ShowDialog();
            this.Close();

        }

        private void viewJobCardsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form jobcardform = new JobCardView();
            jobcardform.ShowDialog();
            this.Close();
        }

        private void updateJobCardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form jobCardUpdate = new Job_Update();
            jobCardUpdate.ShowDialog();
            this.Close();
        }
    }
}
