﻿namespace Job
{
    partial class HomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.textBox136 = new System.Windows.Forms.TextBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.label118 = new System.Windows.Forms.Label();
            this.textBox106 = new System.Windows.Forms.TextBox();
            this.textBox107 = new System.Windows.Forms.TextBox();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.textBox108 = new System.Windows.Forms.TextBox();
            this.textBox109 = new System.Windows.Forms.TextBox();
            this.textBox110 = new System.Windows.Forms.TextBox();
            this.textBox111 = new System.Windows.Forms.TextBox();
            this.textBox112 = new System.Windows.Forms.TextBox();
            this.textBox113 = new System.Windows.Forms.TextBox();
            this.textBox114 = new System.Windows.Forms.TextBox();
            this.textBox115 = new System.Windows.Forms.TextBox();
            this.textBox116 = new System.Windows.Forms.TextBox();
            this.textBox117 = new System.Windows.Forms.TextBox();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.textBox118 = new System.Windows.Forms.TextBox();
            this.textBox119 = new System.Windows.Forms.TextBox();
            this.textBox120 = new System.Windows.Forms.TextBox();
            this.textBox121 = new System.Windows.Forms.TextBox();
            this.textBox122 = new System.Windows.Forms.TextBox();
            this.textBox123 = new System.Windows.Forms.TextBox();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.textBox124 = new System.Windows.Forms.TextBox();
            this.textBox125 = new System.Windows.Forms.TextBox();
            this.textBox126 = new System.Windows.Forms.TextBox();
            this.textBox127 = new System.Windows.Forms.TextBox();
            this.textBox128 = new System.Windows.Forms.TextBox();
            this.textBox129 = new System.Windows.Forms.TextBox();
            this.textBox130 = new System.Windows.Forms.TextBox();
            this.textBox131 = new System.Windows.Forms.TextBox();
            this.textBox132 = new System.Windows.Forms.TextBox();
            this.textBox133 = new System.Windows.Forms.TextBox();
            this.textBox134 = new System.Windows.Forms.TextBox();
            this.textBox135 = new System.Windows.Forms.TextBox();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.label85 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.textBox94 = new System.Windows.Forms.TextBox();
            this.textBox95 = new System.Windows.Forms.TextBox();
            this.textBox96 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label91 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.textBox97 = new System.Windows.Forms.TextBox();
            this.label93 = new System.Windows.Forms.Label();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.textBox98 = new System.Windows.Forms.TextBox();
            this.label94 = new System.Windows.Forms.Label();
            this.textBox99 = new System.Windows.Forms.TextBox();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.label97 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.textBox100 = new System.Windows.Forms.TextBox();
            this.textBox101 = new System.Windows.Forms.TextBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.label100 = new System.Windows.Forms.Label();
            this.textBox102 = new System.Windows.Forms.TextBox();
            this.textBox103 = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.textBox104 = new System.Windows.Forms.TextBox();
            this.label103 = new System.Windows.Forms.Label();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.Size = new System.Windows.Forms.GroupBox();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.textBox105 = new System.Windows.Forms.TextBox();
            this.label112 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label113 = new System.Windows.Forms.Label();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label114 = new System.Windows.Forms.Label();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label115 = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.label92 = new System.Windows.Forms.Label();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button5 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox36 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox141 = new System.Windows.Forms.TextBox();
            this.label146 = new System.Windows.Forms.Label();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.groupBox35 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label144 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.groupBox34 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.textBox140 = new System.Windows.Forms.TextBox();
            this.groupBox32 = new System.Windows.Forms.GroupBox();
            this.textBox139 = new System.Windows.Forms.TextBox();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.textBox138 = new System.Windows.Forms.TextBox();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label143 = new System.Windows.Forms.Label();
            this.textBox137 = new System.Windows.Forms.TextBox();
            this.label142 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.surveysToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.captureSurveyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewSurveysToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jobsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewJobCardsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sMMESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.surveyReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jobCardReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sMMEReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewSMMEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewSMMESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateSMMEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateJobCardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.Size.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox36.SuspendLayout();
            this.groupBox29.SuspendLayout();
            this.groupBox35.SuspendLayout();
            this.groupBox34.SuspendLayout();
            this.groupBox33.SuspendLayout();
            this.groupBox32.SuspendLayout();
            this.groupBox31.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 157);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1917, 777);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox28);
            this.tabPage1.Controls.Add(this.groupBox14);
            this.tabPage1.Controls.Add(this.groupBox12);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1909, 748);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Section 1";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.textBox136);
            this.groupBox28.Location = new System.Drawing.Point(1176, 291);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Size = new System.Drawing.Size(574, 100);
            this.groupBox28.TabIndex = 22;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "Comments";
            // 
            // textBox136
            // 
            this.textBox136.Location = new System.Drawing.Point(62, 31);
            this.textBox136.Multiline = true;
            this.textBox136.Name = "textBox136";
            this.textBox136.Size = new System.Drawing.Size(471, 57);
            this.textBox136.TabIndex = 0;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.button2);
            this.groupBox14.Controls.Add(this.groupBox25);
            this.groupBox14.Controls.Add(this.groupBox24);
            this.groupBox14.Controls.Add(this.groupBox26);
            this.groupBox14.Controls.Add(this.groupBox27);
            this.groupBox14.Location = new System.Drawing.Point(6, 404);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(1744, 307);
            this.groupBox14.TabIndex = 21;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "RETROFITTING";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(35, 34);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(8, 8);
            this.button2.TabIndex = 16;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.label118);
            this.groupBox25.Controls.Add(this.textBox106);
            this.groupBox25.Controls.Add(this.textBox107);
            this.groupBox25.Controls.Add(this.label119);
            this.groupBox25.Controls.Add(this.label120);
            this.groupBox25.Location = new System.Drawing.Point(1257, 38);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(395, 127);
            this.groupBox25.TabIndex = 14;
            this.groupBox25.TabStop = false;
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(8, 58);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(87, 17);
            this.label118.TabIndex = 26;
            this.label118.Text = "VJ Coupling ";
            // 
            // textBox106
            // 
            this.textBox106.Location = new System.Drawing.Point(234, 58);
            this.textBox106.Name = "textBox106";
            this.textBox106.Size = new System.Drawing.Size(100, 22);
            this.textBox106.TabIndex = 15;
            // 
            // textBox107
            // 
            this.textBox107.Location = new System.Drawing.Point(116, 58);
            this.textBox107.Name = "textBox107";
            this.textBox107.Size = new System.Drawing.Size(100, 22);
            this.textBox107.TabIndex = 14;
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(245, 33);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(89, 17);
            this.label119.TabIndex = 13;
            this.label119.Text = "Size : 20 mm";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(125, 33);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(89, 17);
            this.label120.TabIndex = 12;
            this.label120.Text = "Size : 15 mm";
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.label121);
            this.groupBox24.Controls.Add(this.label122);
            this.groupBox24.Controls.Add(this.label123);
            this.groupBox24.Controls.Add(this.label124);
            this.groupBox24.Controls.Add(this.label125);
            this.groupBox24.Controls.Add(this.textBox108);
            this.groupBox24.Controls.Add(this.textBox109);
            this.groupBox24.Controls.Add(this.textBox110);
            this.groupBox24.Controls.Add(this.textBox111);
            this.groupBox24.Controls.Add(this.textBox112);
            this.groupBox24.Controls.Add(this.textBox113);
            this.groupBox24.Controls.Add(this.textBox114);
            this.groupBox24.Controls.Add(this.textBox115);
            this.groupBox24.Controls.Add(this.textBox116);
            this.groupBox24.Controls.Add(this.textBox117);
            this.groupBox24.Controls.Add(this.label126);
            this.groupBox24.Controls.Add(this.label127);
            this.groupBox24.Location = new System.Drawing.Point(856, 38);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(395, 254);
            this.groupBox24.TabIndex = 13;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "Galvanised Mild Steel Pipe";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(29, 188);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(54, 17);
            this.label121.TabIndex = 13;
            this.label121.Text = "150mm";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(29, 160);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(54, 17);
            this.label122.TabIndex = 29;
            this.label122.Text = "200mm";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(29, 132);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(54, 17);
            this.label123.TabIndex = 28;
            this.label123.Text = "300mm";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(29, 104);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(54, 17);
            this.label124.TabIndex = 27;
            this.label124.Text = "400mm";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(29, 74);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(54, 17);
            this.label125.TabIndex = 26;
            this.label125.Text = "700mm";
            // 
            // textBox108
            // 
            this.textBox108.Location = new System.Drawing.Point(264, 183);
            this.textBox108.Name = "textBox108";
            this.textBox108.Size = new System.Drawing.Size(100, 22);
            this.textBox108.TabIndex = 23;
            // 
            // textBox109
            // 
            this.textBox109.Location = new System.Drawing.Point(151, 183);
            this.textBox109.Name = "textBox109";
            this.textBox109.Size = new System.Drawing.Size(100, 22);
            this.textBox109.TabIndex = 22;
            // 
            // textBox110
            // 
            this.textBox110.Location = new System.Drawing.Point(264, 155);
            this.textBox110.Name = "textBox110";
            this.textBox110.Size = new System.Drawing.Size(100, 22);
            this.textBox110.TabIndex = 21;
            // 
            // textBox111
            // 
            this.textBox111.Location = new System.Drawing.Point(151, 155);
            this.textBox111.Name = "textBox111";
            this.textBox111.Size = new System.Drawing.Size(100, 22);
            this.textBox111.TabIndex = 20;
            // 
            // textBox112
            // 
            this.textBox112.Location = new System.Drawing.Point(264, 127);
            this.textBox112.Name = "textBox112";
            this.textBox112.Size = new System.Drawing.Size(100, 22);
            this.textBox112.TabIndex = 19;
            // 
            // textBox113
            // 
            this.textBox113.Location = new System.Drawing.Point(151, 127);
            this.textBox113.Name = "textBox113";
            this.textBox113.Size = new System.Drawing.Size(100, 22);
            this.textBox113.TabIndex = 18;
            // 
            // textBox114
            // 
            this.textBox114.Location = new System.Drawing.Point(264, 99);
            this.textBox114.Name = "textBox114";
            this.textBox114.Size = new System.Drawing.Size(100, 22);
            this.textBox114.TabIndex = 17;
            // 
            // textBox115
            // 
            this.textBox115.Location = new System.Drawing.Point(151, 99);
            this.textBox115.Name = "textBox115";
            this.textBox115.Size = new System.Drawing.Size(100, 22);
            this.textBox115.TabIndex = 16;
            // 
            // textBox116
            // 
            this.textBox116.Location = new System.Drawing.Point(264, 71);
            this.textBox116.Name = "textBox116";
            this.textBox116.Size = new System.Drawing.Size(100, 22);
            this.textBox116.TabIndex = 15;
            // 
            // textBox117
            // 
            this.textBox117.Location = new System.Drawing.Point(151, 71);
            this.textBox117.Name = "textBox117";
            this.textBox117.Size = new System.Drawing.Size(100, 22);
            this.textBox117.TabIndex = 14;
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(266, 42);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(89, 17);
            this.label126.TabIndex = 13;
            this.label126.Text = "Size : 20 mm";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(148, 42);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(89, 17);
            this.label127.TabIndex = 12;
            this.label127.Text = "Size : 15 mm";
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.label128);
            this.groupBox26.Controls.Add(this.label129);
            this.groupBox26.Controls.Add(this.label130);
            this.groupBox26.Controls.Add(this.textBox118);
            this.groupBox26.Controls.Add(this.textBox119);
            this.groupBox26.Controls.Add(this.textBox120);
            this.groupBox26.Controls.Add(this.textBox121);
            this.groupBox26.Controls.Add(this.textBox122);
            this.groupBox26.Controls.Add(this.textBox123);
            this.groupBox26.Controls.Add(this.label131);
            this.groupBox26.Controls.Add(this.label132);
            this.groupBox26.Location = new System.Drawing.Point(455, 38);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(395, 254);
            this.groupBox26.TabIndex = 12;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Reducing 15 x 20";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(29, 132);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(45, 17);
            this.label128.TabIndex = 28;
            this.label128.Text = "Elbow";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Location = new System.Drawing.Point(29, 104);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(40, 17);
            this.label129.TabIndex = 27;
            this.label129.Text = "Bush";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Location = new System.Drawing.Point(29, 74);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(51, 17);
            this.label130.TabIndex = 26;
            this.label130.Text = "Socket";
            // 
            // textBox118
            // 
            this.textBox118.Location = new System.Drawing.Point(264, 127);
            this.textBox118.Name = "textBox118";
            this.textBox118.Size = new System.Drawing.Size(100, 22);
            this.textBox118.TabIndex = 19;
            // 
            // textBox119
            // 
            this.textBox119.Location = new System.Drawing.Point(151, 127);
            this.textBox119.Name = "textBox119";
            this.textBox119.Size = new System.Drawing.Size(100, 22);
            this.textBox119.TabIndex = 18;
            // 
            // textBox120
            // 
            this.textBox120.Location = new System.Drawing.Point(264, 99);
            this.textBox120.Name = "textBox120";
            this.textBox120.Size = new System.Drawing.Size(100, 22);
            this.textBox120.TabIndex = 17;
            // 
            // textBox121
            // 
            this.textBox121.Location = new System.Drawing.Point(151, 99);
            this.textBox121.Name = "textBox121";
            this.textBox121.Size = new System.Drawing.Size(100, 22);
            this.textBox121.TabIndex = 16;
            // 
            // textBox122
            // 
            this.textBox122.Location = new System.Drawing.Point(264, 71);
            this.textBox122.Name = "textBox122";
            this.textBox122.Size = new System.Drawing.Size(100, 22);
            this.textBox122.TabIndex = 15;
            // 
            // textBox123
            // 
            this.textBox123.Location = new System.Drawing.Point(151, 71);
            this.textBox123.Name = "textBox123";
            this.textBox123.Size = new System.Drawing.Size(100, 22);
            this.textBox123.TabIndex = 14;
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Location = new System.Drawing.Point(266, 42);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(89, 17);
            this.label131.TabIndex = 13;
            this.label131.Text = "Size : 20 mm";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Location = new System.Drawing.Point(148, 42);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(89, 17);
            this.label132.TabIndex = 12;
            this.label132.Text = "Size : 15 mm";
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.label133);
            this.groupBox27.Controls.Add(this.label134);
            this.groupBox27.Controls.Add(this.label135);
            this.groupBox27.Controls.Add(this.label136);
            this.groupBox27.Controls.Add(this.label137);
            this.groupBox27.Controls.Add(this.label138);
            this.groupBox27.Controls.Add(this.textBox124);
            this.groupBox27.Controls.Add(this.textBox125);
            this.groupBox27.Controls.Add(this.textBox126);
            this.groupBox27.Controls.Add(this.textBox127);
            this.groupBox27.Controls.Add(this.textBox128);
            this.groupBox27.Controls.Add(this.textBox129);
            this.groupBox27.Controls.Add(this.textBox130);
            this.groupBox27.Controls.Add(this.textBox131);
            this.groupBox27.Controls.Add(this.textBox132);
            this.groupBox27.Controls.Add(this.textBox133);
            this.groupBox27.Controls.Add(this.textBox134);
            this.groupBox27.Controls.Add(this.textBox135);
            this.groupBox27.Controls.Add(this.label139);
            this.groupBox27.Controls.Add(this.label140);
            this.groupBox27.Location = new System.Drawing.Point(54, 38);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(395, 254);
            this.groupBox27.TabIndex = 11;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "Galvanised Fittings";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(29, 216);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(51, 17);
            this.label133.TabIndex = 21;
            this.label133.Text = "Socket";
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Location = new System.Drawing.Point(29, 188);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(84, 17);
            this.label134.TabIndex = 13;
            this.label134.Text = "Long Nipple";
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Location = new System.Drawing.Point(29, 160);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(48, 17);
            this.label135.TabIndex = 29;
            this.label135.Text = "Nipple";
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Location = new System.Drawing.Point(29, 132);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(46, 17);
            this.label136.TabIndex = 28;
            this.label136.Text = "PLUG";
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Location = new System.Drawing.Point(29, 104);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(58, 17);
            this.label137.TabIndex = 27;
            this.label137.Text = "ELBOW";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Location = new System.Drawing.Point(29, 74);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(35, 17);
            this.label138.TabIndex = 26;
            this.label138.Text = "TEE";
            // 
            // textBox124
            // 
            this.textBox124.Location = new System.Drawing.Point(264, 211);
            this.textBox124.Name = "textBox124";
            this.textBox124.Size = new System.Drawing.Size(100, 22);
            this.textBox124.TabIndex = 25;
            // 
            // textBox125
            // 
            this.textBox125.Location = new System.Drawing.Point(151, 211);
            this.textBox125.Name = "textBox125";
            this.textBox125.Size = new System.Drawing.Size(100, 22);
            this.textBox125.TabIndex = 24;
            // 
            // textBox126
            // 
            this.textBox126.Location = new System.Drawing.Point(264, 183);
            this.textBox126.Name = "textBox126";
            this.textBox126.Size = new System.Drawing.Size(100, 22);
            this.textBox126.TabIndex = 23;
            // 
            // textBox127
            // 
            this.textBox127.Location = new System.Drawing.Point(151, 183);
            this.textBox127.Name = "textBox127";
            this.textBox127.Size = new System.Drawing.Size(100, 22);
            this.textBox127.TabIndex = 22;
            // 
            // textBox128
            // 
            this.textBox128.Location = new System.Drawing.Point(264, 155);
            this.textBox128.Name = "textBox128";
            this.textBox128.Size = new System.Drawing.Size(100, 22);
            this.textBox128.TabIndex = 21;
            // 
            // textBox129
            // 
            this.textBox129.Location = new System.Drawing.Point(151, 155);
            this.textBox129.Name = "textBox129";
            this.textBox129.Size = new System.Drawing.Size(100, 22);
            this.textBox129.TabIndex = 20;
            // 
            // textBox130
            // 
            this.textBox130.Location = new System.Drawing.Point(264, 127);
            this.textBox130.Name = "textBox130";
            this.textBox130.Size = new System.Drawing.Size(100, 22);
            this.textBox130.TabIndex = 19;
            // 
            // textBox131
            // 
            this.textBox131.Location = new System.Drawing.Point(151, 127);
            this.textBox131.Name = "textBox131";
            this.textBox131.Size = new System.Drawing.Size(100, 22);
            this.textBox131.TabIndex = 18;
            // 
            // textBox132
            // 
            this.textBox132.Location = new System.Drawing.Point(264, 99);
            this.textBox132.Name = "textBox132";
            this.textBox132.Size = new System.Drawing.Size(100, 22);
            this.textBox132.TabIndex = 17;
            // 
            // textBox133
            // 
            this.textBox133.Location = new System.Drawing.Point(151, 99);
            this.textBox133.Name = "textBox133";
            this.textBox133.Size = new System.Drawing.Size(100, 22);
            this.textBox133.TabIndex = 16;
            // 
            // textBox134
            // 
            this.textBox134.Location = new System.Drawing.Point(264, 71);
            this.textBox134.Name = "textBox134";
            this.textBox134.Size = new System.Drawing.Size(100, 22);
            this.textBox134.TabIndex = 15;
            // 
            // textBox135
            // 
            this.textBox135.Location = new System.Drawing.Point(151, 71);
            this.textBox135.Name = "textBox135";
            this.textBox135.Size = new System.Drawing.Size(100, 22);
            this.textBox135.TabIndex = 14;
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Location = new System.Drawing.Point(266, 42);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(89, 17);
            this.label139.TabIndex = 13;
            this.label139.Text = "Size : 20 mm";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Location = new System.Drawing.Point(148, 42);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(89, 17);
            this.label140.TabIndex = 12;
            this.label140.Text = "Size : 15 mm";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.groupBox20);
            this.groupBox12.Controls.Add(this.groupBox21);
            this.groupBox12.Location = new System.Drawing.Point(1176, 11);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(574, 279);
            this.groupBox12.TabIndex = 7;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "FITTING REQUIRED";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.label79);
            this.groupBox20.Controls.Add(this.label81);
            this.groupBox20.Controls.Add(this.label82);
            this.groupBox20.Controls.Add(this.label83);
            this.groupBox20.Controls.Add(this.label84);
            this.groupBox20.Controls.Add(this.textBox89);
            this.groupBox20.Controls.Add(this.textBox90);
            this.groupBox20.Controls.Add(this.textBox91);
            this.groupBox20.Controls.Add(this.textBox92);
            this.groupBox20.Location = new System.Drawing.Point(31, 157);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(502, 98);
            this.groupBox20.TabIndex = 13;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "1.2 Yard Connection";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(48, 60);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(19, 17);
            this.label79.TabIndex = 18;
            this.label79.Text = "M";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(209, 37);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(51, 17);
            this.label81.TabIndex = 13;
            this.label81.Text = "Paving";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(311, 37);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(46, 17);
            this.label82.TabIndex = 14;
            this.label82.Text = "Grass";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(404, 37);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(55, 17);
            this.label83.TabIndex = 16;
            this.label83.Text = "Asphalt";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(99, 37);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(65, 17);
            this.label84.TabIndex = 11;
            this.label84.Text = "Concrete";
            // 
            // textBox89
            // 
            this.textBox89.Location = new System.Drawing.Point(290, 57);
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(100, 22);
            this.textBox89.TabIndex = 11;
            // 
            // textBox90
            // 
            this.textBox90.Location = new System.Drawing.Point(184, 57);
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(100, 22);
            this.textBox90.TabIndex = 10;
            // 
            // textBox91
            // 
            this.textBox91.Location = new System.Drawing.Point(78, 58);
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(100, 22);
            this.textBox91.TabIndex = 9;
            // 
            // textBox92
            // 
            this.textBox92.Location = new System.Drawing.Point(396, 57);
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(100, 22);
            this.textBox92.TabIndex = 11;
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.label85);
            this.groupBox21.Controls.Add(this.label87);
            this.groupBox21.Controls.Add(this.label88);
            this.groupBox21.Controls.Add(this.label89);
            this.groupBox21.Controls.Add(this.label90);
            this.groupBox21.Controls.Add(this.textBox93);
            this.groupBox21.Controls.Add(this.textBox94);
            this.groupBox21.Controls.Add(this.textBox95);
            this.groupBox21.Controls.Add(this.textBox96);
            this.groupBox21.Location = new System.Drawing.Point(31, 52);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(502, 90);
            this.groupBox21.TabIndex = 12;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "1.1 New Pipe";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(48, 57);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(19, 17);
            this.label85.TabIndex = 17;
            this.label85.Text = "M";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(99, 34);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(65, 17);
            this.label87.TabIndex = 4;
            this.label87.Text = "Concrete";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(404, 33);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(55, 17);
            this.label88.TabIndex = 15;
            this.label88.Text = "Asphalt";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(311, 34);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(46, 17);
            this.label89.TabIndex = 13;
            this.label89.Text = "Grass";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(209, 34);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(51, 17);
            this.label90.TabIndex = 12;
            this.label90.Text = "Paving";
            // 
            // textBox93
            // 
            this.textBox93.Location = new System.Drawing.Point(290, 57);
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new System.Drawing.Size(100, 22);
            this.textBox93.TabIndex = 11;
            // 
            // textBox94
            // 
            this.textBox94.Location = new System.Drawing.Point(184, 57);
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new System.Drawing.Size(100, 22);
            this.textBox94.TabIndex = 10;
            // 
            // textBox95
            // 
            this.textBox95.Location = new System.Drawing.Point(78, 57);
            this.textBox95.Name = "textBox95";
            this.textBox95.Size = new System.Drawing.Size(100, 22);
            this.textBox95.TabIndex = 9;
            // 
            // textBox96
            // 
            this.textBox96.Location = new System.Drawing.Point(396, 57);
            this.textBox96.Name = "textBox96";
            this.textBox96.Size = new System.Drawing.Size(100, 22);
            this.textBox96.TabIndex = 12;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label91);
            this.groupBox1.Controls.Add(this.groupBox16);
            this.groupBox1.Controls.Add(this.groupBox17);
            this.groupBox1.Controls.Add(this.groupBox18);
            this.groupBox1.Controls.Add(this.groupBox19);
            this.groupBox1.Location = new System.Drawing.Point(802, 11);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(368, 387);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "FITTING REQUIRED";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(221, 50);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(24, 17);
            this.label91.TabIndex = 12;
            this.label91.Text = "20";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.textBox97);
            this.groupBox16.Controls.Add(this.label93);
            this.groupBox16.Location = new System.Drawing.Point(31, 313);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(304, 62);
            this.groupBox16.TabIndex = 15;
            this.groupBox16.TabStop = false;
            // 
            // textBox97
            // 
            this.textBox97.Location = new System.Drawing.Point(100, 21);
            this.textBox97.Name = "textBox97";
            this.textBox97.Size = new System.Drawing.Size(100, 22);
            this.textBox97.TabIndex = 7;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(16, 20);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(62, 17);
            this.label93.TabIndex = 6;
            this.label93.Text = "Reducer";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.textBox98);
            this.groupBox17.Controls.Add(this.label94);
            this.groupBox17.Controls.Add(this.textBox99);
            this.groupBox17.Controls.Add(this.label95);
            this.groupBox17.Controls.Add(this.label96);
            this.groupBox17.Location = new System.Drawing.Point(31, 222);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(304, 85);
            this.groupBox17.TabIndex = 14;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Gate Valve";
            // 
            // textBox98
            // 
            this.textBox98.Location = new System.Drawing.Point(39, 52);
            this.textBox98.Name = "textBox98";
            this.textBox98.Size = new System.Drawing.Size(100, 22);
            this.textBox98.TabIndex = 10;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(212, 31);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(24, 17);
            this.label94.TabIndex = 11;
            this.label94.Text = "25";
            // 
            // textBox99
            // 
            this.textBox99.Location = new System.Drawing.Point(177, 54);
            this.textBox99.Name = "textBox99";
            this.textBox99.Size = new System.Drawing.Size(100, 22);
            this.textBox99.TabIndex = 9;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(74, 32);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(24, 17);
            this.label95.TabIndex = 11;
            this.label95.Text = "20";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(6, 24);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(0, 17);
            this.label96.TabIndex = 4;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.label97);
            this.groupBox18.Controls.Add(this.label99);
            this.groupBox18.Controls.Add(this.textBox100);
            this.groupBox18.Controls.Add(this.textBox101);
            this.groupBox18.Location = new System.Drawing.Point(31, 112);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(304, 94);
            this.groupBox18.TabIndex = 13;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Male Adapter";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(190, 33);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(46, 17);
            this.label97.TabIndex = 20;
            this.label97.Text = "25 x 1";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(54, 33);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(58, 17);
            this.label99.TabIndex = 12;
            this.label99.Text = "20 x 3/4";
            // 
            // textBox100
            // 
            this.textBox100.Location = new System.Drawing.Point(168, 57);
            this.textBox100.Name = "textBox100";
            this.textBox100.Size = new System.Drawing.Size(100, 22);
            this.textBox100.TabIndex = 10;
            this.textBox100.TextChanged += new System.EventHandler(this.textBox100_TextChanged);
            // 
            // textBox101
            // 
            this.textBox101.Location = new System.Drawing.Point(39, 57);
            this.textBox101.Name = "textBox101";
            this.textBox101.Size = new System.Drawing.Size(100, 22);
            this.textBox101.TabIndex = 9;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.label100);
            this.groupBox19.Controls.Add(this.textBox102);
            this.groupBox19.Controls.Add(this.textBox103);
            this.groupBox19.Location = new System.Drawing.Point(31, 21);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(304, 85);
            this.groupBox19.TabIndex = 12;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Sockets";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(54, 29);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(24, 17);
            this.label100.TabIndex = 11;
            this.label100.Text = "25";
            // 
            // textBox102
            // 
            this.textBox102.Location = new System.Drawing.Point(153, 49);
            this.textBox102.Name = "textBox102";
            this.textBox102.Size = new System.Drawing.Size(100, 22);
            this.textBox102.TabIndex = 10;
            // 
            // textBox103
            // 
            this.textBox103.Location = new System.Drawing.Point(19, 49);
            this.textBox103.Name = "textBox103";
            this.textBox103.Size = new System.Drawing.Size(100, 22);
            this.textBox103.TabIndex = 9;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label101);
            this.groupBox5.Controls.Add(this.label102);
            this.groupBox5.Controls.Add(this.groupBox10);
            this.groupBox5.Controls.Add(this.groupBox15);
            this.groupBox5.Controls.Add(this.groupBox11);
            this.groupBox5.Controls.Add(this.Size);
            this.groupBox5.Location = new System.Drawing.Point(447, 8);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(349, 390);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "EXISTING YARD CONNECTION";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(182, 165);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(24, 17);
            this.label101.TabIndex = 8;
            this.label101.Text = "20";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(114, 165);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(24, 17);
            this.label102.TabIndex = 9;
            this.label102.Text = "25";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.textBox104);
            this.groupBox10.Controls.Add(this.label103);
            this.groupBox10.Location = new System.Drawing.Point(24, 321);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(304, 62);
            this.groupBox10.TabIndex = 11;
            this.groupBox10.TabStop = false;
            // 
            // textBox104
            // 
            this.textBox104.Location = new System.Drawing.Point(145, 20);
            this.textBox104.Name = "textBox104";
            this.textBox104.Size = new System.Drawing.Size(100, 22);
            this.textBox104.TabIndex = 7;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(16, 20);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(98, 17);
            this.label103.TabIndex = 6;
            this.label103.Text = "Pipe Required";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.label105);
            this.groupBox15.Controls.Add(this.label106);
            this.groupBox15.Controls.Add(this.label109);
            this.groupBox15.Controls.Add(this.radioButton15);
            this.groupBox15.Controls.Add(this.radioButton16);
            this.groupBox15.Location = new System.Drawing.Point(24, 232);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(304, 85);
            this.groupBox15.TabIndex = 10;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Change Position";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(155, 28);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(18, 17);
            this.label105.TabIndex = 10;
            this.label105.Text = "N";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(93, 28);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(17, 17);
            this.label106.TabIndex = 9;
            this.label106.Text = "Y";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(6, 24);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(0, 17);
            this.label109.TabIndex = 4;
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Location = new System.Drawing.Point(158, 58);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(17, 16);
            this.radioButton15.TabIndex = 5;
            this.radioButton15.UseVisualStyleBackColor = true;
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Checked = true;
            this.radioButton16.Location = new System.Drawing.Point(90, 58);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(17, 16);
            this.radioButton16.TabIndex = 4;
            this.radioButton16.TabStop = true;
            this.radioButton16.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.radioButton9);
            this.groupBox11.Controls.Add(this.radioButton10);
            this.groupBox11.Location = new System.Drawing.Point(24, 139);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(304, 85);
            this.groupBox11.TabIndex = 9;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Type";
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(162, 54);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(17, 16);
            this.radioButton9.TabIndex = 5;
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Checked = true;
            this.radioButton10.Location = new System.Drawing.Point(93, 54);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(17, 16);
            this.radioButton10.TabIndex = 4;
            this.radioButton10.TabStop = true;
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // Size
            // 
            this.Size.Controls.Add(this.label110);
            this.Size.Controls.Add(this.label111);
            this.Size.Controls.Add(this.radioButton7);
            this.Size.Controls.Add(this.radioButton8);
            this.Size.Location = new System.Drawing.Point(24, 40);
            this.Size.Name = "Size";
            this.Size.Size = new System.Drawing.Size(304, 85);
            this.Size.TabIndex = 7;
            this.Size.TabStop = false;
            this.Size.Text = "Size";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(155, 21);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(24, 17);
            this.label110.TabIndex = 7;
            this.label110.Text = "20";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(84, 21);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(24, 17);
            this.label111.TabIndex = 6;
            this.label111.Text = "25";
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(161, 54);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(17, 16);
            this.radioButton7.TabIndex = 5;
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Checked = true;
            this.radioButton8.Location = new System.Drawing.Point(90, 54);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(17, 16);
            this.radioButton8.TabIndex = 4;
            this.radioButton8.TabStop = true;
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.groupBox9);
            this.groupBox6.Controls.Add(this.groupBox8);
            this.groupBox6.Controls.Add(this.groupBox7);
            this.groupBox6.Controls.Add(this.groupBox13);
            this.groupBox6.Controls.Add(this.label116);
            this.groupBox6.Controls.Add(this.label117);
            this.groupBox6.Location = new System.Drawing.Point(6, 6);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(435, 392);
            this.groupBox6.TabIndex = 4;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "YARD CONNECTION";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.textBox105);
            this.groupBox9.Controls.Add(this.label112);
            this.groupBox9.Location = new System.Drawing.Point(35, 288);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(383, 62);
            this.groupBox9.TabIndex = 9;
            this.groupBox9.TabStop = false;
            // 
            // textBox105
            // 
            this.textBox105.Location = new System.Drawing.Point(237, 21);
            this.textBox105.Name = "textBox105";
            this.textBox105.Size = new System.Drawing.Size(100, 22);
            this.textBox105.TabIndex = 7;
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(16, 20);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(171, 17);
            this.label112.TabIndex = 6;
            this.label112.Text = "Distance From Boundry M";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label113);
            this.groupBox8.Controls.Add(this.radioButton5);
            this.groupBox8.Controls.Add(this.radioButton6);
            this.groupBox8.Location = new System.Drawing.Point(26, 189);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(383, 62);
            this.groupBox8.TabIndex = 8;
            this.groupBox8.TabStop = false;
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(16, 20);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(61, 17);
            this.label113.TabIndex = 6;
            this.label113.Text = "Earthing";
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(310, 21);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(17, 16);
            this.radioButton5.TabIndex = 5;
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Checked = true;
            this.radioButton6.Location = new System.Drawing.Point(237, 21);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(17, 16);
            this.radioButton6.TabIndex = 4;
            this.radioButton6.TabStop = true;
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label114);
            this.groupBox7.Controls.Add(this.radioButton3);
            this.groupBox7.Controls.Add(this.radioButton4);
            this.groupBox7.Location = new System.Drawing.Point(26, 110);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(383, 62);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(16, 20);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(130, 17);
            this.label114.TabIndex = 6;
            this.label114.Text = "Existing Gate Valve";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(310, 21);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(17, 16);
            this.radioButton3.TabIndex = 5;
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Checked = true;
            this.radioButton4.Location = new System.Drawing.Point(237, 21);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(17, 16);
            this.radioButton4.TabIndex = 4;
            this.radioButton4.TabStop = true;
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label115);
            this.groupBox13.Controls.Add(this.radioButton2);
            this.groupBox13.Controls.Add(this.radioButton1);
            this.groupBox13.Location = new System.Drawing.Point(26, 42);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(383, 62);
            this.groupBox13.TabIndex = 6;
            this.groupBox13.TabStop = false;
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(6, 21);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(177, 17);
            this.label115.TabIndex = 4;
            this.label115.Text = "Existing Meter and Meter B";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(310, 21);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(17, 16);
            this.radioButton2.TabIndex = 5;
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(237, 21);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(17, 16);
            this.radioButton1.TabIndex = 4;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(357, 18);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(26, 17);
            this.label116.TabIndex = 5;
            this.label116.Text = "No";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(273, 18);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(32, 17);
            this.label117.TabIndex = 4;
            this.label117.Text = "Yes";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox23);
            this.tabPage2.Controls.Add(this.groupBox22);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1909, 748);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Section 2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox52);
            this.groupBox2.Controls.Add(this.textBox51);
            this.groupBox2.Controls.Add(this.textBox50);
            this.groupBox2.Controls.Add(this.textBox49);
            this.groupBox2.Controls.Add(this.label57);
            this.groupBox2.Controls.Add(this.label56);
            this.groupBox2.Controls.Add(this.label55);
            this.groupBox2.Controls.Add(this.label54);
            this.groupBox2.Controls.Add(this.label53);
            this.groupBox2.Controls.Add(this.label52);
            this.groupBox2.Controls.Add(this.textBox48);
            this.groupBox2.Controls.Add(this.textBox47);
            this.groupBox2.Controls.Add(this.textBox46);
            this.groupBox2.Controls.Add(this.textBox45);
            this.groupBox2.Controls.Add(this.label51);
            this.groupBox2.Controls.Add(this.label50);
            this.groupBox2.Controls.Add(this.label44);
            this.groupBox2.Controls.Add(this.label43);
            this.groupBox2.Controls.Add(this.label42);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.textBox44);
            this.groupBox2.Controls.Add(this.textBox43);
            this.groupBox2.Controls.Add(this.textBox36);
            this.groupBox2.Controls.Add(this.textBox35);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.textBox31);
            this.groupBox2.Controls.Add(this.textBox32);
            this.groupBox2.Controls.Add(this.textBox33);
            this.groupBox2.Controls.Add(this.textBox34);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.textBox30);
            this.groupBox2.Controls.Add(this.textBox29);
            this.groupBox2.Controls.Add(this.textBox28);
            this.groupBox2.Controls.Add(this.textBox27);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.textBox26);
            this.groupBox2.Controls.Add(this.textBox25);
            this.groupBox2.Controls.Add(this.textBox24);
            this.groupBox2.Controls.Add(this.textBox23);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.textBox22);
            this.groupBox2.Controls.Add(this.textBox21);
            this.groupBox2.Controls.Add(this.textBox20);
            this.groupBox2.Controls.Add(this.textBox13);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(6, 347);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1903, 213);
            this.groupBox2.TabIndex = 43;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Plasson Fittings";
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(1517, 175);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(100, 22);
            this.textBox52.TabIndex = 84;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(1517, 146);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(100, 22);
            this.textBox51.TabIndex = 95;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(1517, 110);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(100, 22);
            this.textBox50.TabIndex = 94;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(1517, 74);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(100, 22);
            this.textBox49.TabIndex = 93;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(1514, 43);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(116, 17);
            this.label57.TabIndex = 92;
            this.label57.Text = "Coupling Straight";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(1444, 180);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(55, 17);
            this.label56.TabIndex = 91;
            this.label56.Text = "x 1 1/2\"";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(1444, 147);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(31, 17);
            this.label55.TabIndex = 90;
            this.label55.Text = "x 1\"";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(1444, 112);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(38, 17);
            this.label54.TabIndex = 89;
            this.label54.Text = "x 3/4";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(1444, 81);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(38, 17);
            this.label53.TabIndex = 88;
            this.label53.Text = "x 1/2";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(1447, 43);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(35, 17);
            this.label52.TabIndex = 87;
            this.label52.Text = "Size";
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(1310, 176);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(100, 22);
            this.textBox48.TabIndex = 86;
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(1310, 147);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(100, 22);
            this.textBox47.TabIndex = 85;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(1310, 115);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(100, 22);
            this.textBox46.TabIndex = 84;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(1310, 76);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(100, 22);
            this.textBox45.TabIndex = 83;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(1311, 43);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(79, 17);
            this.label51.TabIndex = 82;
            this.label51.Text = "Elbow male";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(1229, 183);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(55, 17);
            this.label50.TabIndex = 81;
            this.label50.Text = "x 1 1/2\"";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(1229, 150);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(31, 17);
            this.label44.TabIndex = 80;
            this.label44.Text = "x 1\"";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(1229, 115);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(38, 17);
            this.label43.TabIndex = 79;
            this.label43.Text = "x 3/4";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(1229, 79);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(38, 17);
            this.label42.TabIndex = 78;
            this.label42.Text = "x 1/2";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(1232, 43);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(35, 17);
            this.label33.TabIndex = 77;
            this.label33.Text = "Size";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(1099, 43);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(95, 17);
            this.label32.TabIndex = 76;
            this.label32.Text = "Elbow Female";
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(1098, 180);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(100, 22);
            this.textBox44.TabIndex = 75;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(1098, 147);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(100, 22);
            this.textBox43.TabIndex = 74;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(1098, 112);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(100, 22);
            this.textBox36.TabIndex = 73;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(1098, 74);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(100, 22);
            this.textBox35.TabIndex = 72;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(1027, 180);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(34, 17);
            this.label27.TabIndex = 71;
            this.label27.Text = "x 32";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(1027, 147);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(34, 17);
            this.label28.TabIndex = 70;
            this.label28.Text = "x 25";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(1028, 112);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(34, 17);
            this.label29.TabIndex = 69;
            this.label29.Text = "x 20";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(1027, 74);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(34, 17);
            this.label30.TabIndex = 68;
            this.label30.Text = "x 15";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(1028, 43);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(35, 17);
            this.label31.TabIndex = 67;
            this.label31.Text = "Size";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(886, 176);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(100, 22);
            this.textBox31.TabIndex = 66;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(886, 142);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(100, 22);
            this.textBox32.TabIndex = 65;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(886, 107);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(100, 22);
            this.textBox33.TabIndex = 64;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(886, 71);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(100, 22);
            this.textBox34.TabIndex = 63;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(907, 43);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(45, 17);
            this.label26.TabIndex = 62;
            this.label26.Text = "Elbow";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(800, 43);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(35, 17);
            this.label21.TabIndex = 61;
            this.label21.Text = "Size";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(800, 180);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(55, 17);
            this.label22.TabIndex = 60;
            this.label22.Text = "x 1 1/2\"";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(800, 146);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(31, 17);
            this.label23.TabIndex = 59;
            this.label23.Text = "x 1\"";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(800, 111);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(38, 17);
            this.label24.TabIndex = 58;
            this.label24.Text = "x 3/4";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(804, 78);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(38, 17);
            this.label25.TabIndex = 57;
            this.label25.Text = "x 1/2";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(656, 172);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(100, 22);
            this.textBox30.TabIndex = 56;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(656, 138);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(100, 22);
            this.textBox29.TabIndex = 55;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(656, 103);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(100, 22);
            this.textBox28.TabIndex = 54;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(656, 67);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(100, 22);
            this.textBox27.TabIndex = 53;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(653, 39);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(92, 17);
            this.label20.TabIndex = 52;
            this.label20.Text = "Adapter male";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(561, 35);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 17);
            this.label19.TabIndex = 51;
            this.label19.Text = "Size";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(561, 172);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 17);
            this.label15.TabIndex = 50;
            this.label15.Text = "x 1 1/2\"";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(561, 138);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(31, 17);
            this.label16.TabIndex = 49;
            this.label16.Text = "x 1\"";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(561, 103);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(38, 17);
            this.label17.TabIndex = 48;
            this.label17.Text = "x 3/4";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(565, 70);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(38, 17);
            this.label18.TabIndex = 47;
            this.label18.Text = "x 1/2";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(412, 167);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(100, 22);
            this.textBox26.TabIndex = 45;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(412, 133);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(100, 22);
            this.textBox25.TabIndex = 44;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(412, 98);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 22);
            this.textBox24.TabIndex = 43;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(412, 65);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(100, 22);
            this.textBox23.TabIndex = 42;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(409, 35);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 17);
            this.label14.TabIndex = 41;
            this.label14.Text = "TEE Female";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(310, 172);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 17);
            this.label13.TabIndex = 40;
            this.label13.Text = "25x20";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(310, 136);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 17);
            this.label12.TabIndex = 39;
            this.label12.Text = "x 25";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(310, 98);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 17);
            this.label11.TabIndex = 38;
            this.label11.Text = "x 20";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(310, 65);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 17);
            this.label10.TabIndex = 37;
            this.label10.Text = "x 15";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(310, 39);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 17);
            this.label9.TabIndex = 36;
            this.label9.Text = "Size";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(191, 35);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 17);
            this.label8.TabIndex = 35;
            this.label8.Text = "TEE";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(165, 167);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(100, 22);
            this.textBox22.TabIndex = 34;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(165, 135);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(100, 22);
            this.textBox21.TabIndex = 33;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(165, 98);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 22);
            this.textBox20.TabIndex = 32;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(165, 60);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 22);
            this.textBox13.TabIndex = 31;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 17);
            this.label7.TabIndex = 30;
            this.label7.Text = "32 mm";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(29, 136);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 17);
            this.label6.TabIndex = 29;
            this.label6.Text = "25 mm";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 17);
            this.label5.TabIndex = 28;
            this.label5.Text = "20 mm";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 17);
            this.label4.TabIndex = 27;
            this.label4.Text = "15 mm";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox87);
            this.groupBox4.Controls.Add(this.textBox88);
            this.groupBox4.Controls.Add(this.label78);
            this.groupBox4.Controls.Add(this.textBox85);
            this.groupBox4.Controls.Add(this.textBox86);
            this.groupBox4.Controls.Add(this.label77);
            this.groupBox4.Controls.Add(this.textBox81);
            this.groupBox4.Controls.Add(this.textBox82);
            this.groupBox4.Controls.Add(this.label76);
            this.groupBox4.Controls.Add(this.textBox77);
            this.groupBox4.Controls.Add(this.textBox78);
            this.groupBox4.Controls.Add(this.label75);
            this.groupBox4.Controls.Add(this.textBox73);
            this.groupBox4.Controls.Add(this.textBox74);
            this.groupBox4.Controls.Add(this.label73);
            this.groupBox4.Controls.Add(this.textBox69);
            this.groupBox4.Controls.Add(this.textBox70);
            this.groupBox4.Controls.Add(this.label72);
            this.groupBox4.Controls.Add(this.textBox65);
            this.groupBox4.Controls.Add(this.textBox66);
            this.groupBox4.Controls.Add(this.label71);
            this.groupBox4.Controls.Add(this.textBox61);
            this.groupBox4.Controls.Add(this.textBox62);
            this.groupBox4.Controls.Add(this.label70);
            this.groupBox4.Controls.Add(this.textBox59);
            this.groupBox4.Controls.Add(this.textBox60);
            this.groupBox4.Controls.Add(this.label69);
            this.groupBox4.Controls.Add(this.textBox57);
            this.groupBox4.Controls.Add(this.textBox58);
            this.groupBox4.Controls.Add(this.label68);
            this.groupBox4.Controls.Add(this.textBox63);
            this.groupBox4.Controls.Add(this.textBox64);
            this.groupBox4.Controls.Add(this.label74);
            this.groupBox4.Controls.Add(this.label80);
            this.groupBox4.Controls.Add(this.textBox67);
            this.groupBox4.Controls.Add(this.textBox68);
            this.groupBox4.Controls.Add(this.textBox71);
            this.groupBox4.Controls.Add(this.textBox72);
            this.groupBox4.Controls.Add(this.label86);
            this.groupBox4.Controls.Add(this.textBox75);
            this.groupBox4.Controls.Add(this.textBox76);
            this.groupBox4.Controls.Add(this.label92);
            this.groupBox4.Controls.Add(this.textBox79);
            this.groupBox4.Controls.Add(this.textBox80);
            this.groupBox4.Controls.Add(this.label98);
            this.groupBox4.Controls.Add(this.label104);
            this.groupBox4.Controls.Add(this.textBox83);
            this.groupBox4.Controls.Add(this.textBox84);
            this.groupBox4.Controls.Add(this.label107);
            this.groupBox4.Controls.Add(this.label108);
            this.groupBox4.Location = new System.Drawing.Point(3, 566);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1903, 147);
            this.groupBox4.TabIndex = 42;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Taps, Fittings and Mixers";
            // 
            // textBox87
            // 
            this.textBox87.Location = new System.Drawing.Point(1738, 96);
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(100, 22);
            this.textBox87.TabIndex = 114;
            // 
            // textBox88
            // 
            this.textBox88.Location = new System.Drawing.Point(1738, 68);
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(100, 22);
            this.textBox88.TabIndex = 113;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(1742, 43);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(57, 17);
            this.label78.TabIndex = 112;
            this.label78.Text = "Washer";
            // 
            // textBox85
            // 
            this.textBox85.Location = new System.Drawing.Point(1619, 96);
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(100, 22);
            this.textBox85.TabIndex = 111;
            // 
            // textBox86
            // 
            this.textBox86.Location = new System.Drawing.Point(1619, 68);
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(100, 22);
            this.textBox86.TabIndex = 110;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(1633, 43);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(82, 17);
            this.label77.TabIndex = 109;
            this.label77.Text = "Brass Head";
            // 
            // textBox81
            // 
            this.textBox81.Location = new System.Drawing.Point(1509, 96);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(100, 22);
            this.textBox81.TabIndex = 108;
            // 
            // textBox82
            // 
            this.textBox82.Location = new System.Drawing.Point(1509, 68);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(100, 22);
            this.textBox82.TabIndex = 107;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(1523, 43);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(72, 17);
            this.label76.TabIndex = 106;
            this.label76.Text = "Star Head";
            // 
            // textBox77
            // 
            this.textBox77.Location = new System.Drawing.Point(1403, 96);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(100, 22);
            this.textBox77.TabIndex = 105;
            // 
            // textBox78
            // 
            this.textBox78.Location = new System.Drawing.Point(1403, 68);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(100, 22);
            this.textBox78.TabIndex = 104;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(1411, 45);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(95, 17);
            this.label75.TabIndex = 103;
            this.label75.Text = "Chrome Head";
            // 
            // textBox73
            // 
            this.textBox73.Location = new System.Drawing.Point(1293, 97);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(100, 22);
            this.textBox73.TabIndex = 102;
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(1293, 68);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(100, 22);
            this.textBox74.TabIndex = 101;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(1295, 46);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(78, 17);
            this.label73.TabIndex = 100;
            this.label73.Text = "Gate Valve";
            // 
            // textBox69
            // 
            this.textBox69.Location = new System.Drawing.Point(1187, 96);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(100, 22);
            this.textBox69.TabIndex = 99;
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(1187, 68);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(100, 22);
            this.textBox70.TabIndex = 98;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(1195, 45);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(70, 17);
            this.label72.TabIndex = 97;
            this.label72.Text = "Ball Valve";
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(1080, 97);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(100, 22);
            this.textBox65.TabIndex = 96;
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(1080, 69);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(100, 22);
            this.textBox66.TabIndex = 95;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(1088, 46);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(72, 17);
            this.label71.TabIndex = 94;
            this.label71.Text = "Sink Mixer";
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(974, 97);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(100, 22);
            this.textBox61.TabIndex = 93;
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(974, 69);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(100, 22);
            this.textBox62.TabIndex = 92;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(974, 45);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(80, 17);
            this.label70.TabIndex = 91;
            this.label70.Text = "Basin Mixer";
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(868, 97);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(100, 22);
            this.textBox59.TabIndex = 90;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(868, 69);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(100, 22);
            this.textBox60.TabIndex = 89;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(873, 46);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(83, 17);
            this.label69.TabIndex = 88;
            this.label69.Text = "Bath MIXER";
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(762, 97);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(100, 22);
            this.textBox57.TabIndex = 87;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(762, 69);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(100, 22);
            this.textBox58.TabIndex = 86;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(770, 45);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(97, 17);
            this.label68.TabIndex = 85;
            this.label68.Text = "Hand Shower ";
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(656, 98);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(100, 22);
            this.textBox63.TabIndex = 84;
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(656, 70);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(100, 22);
            this.textBox64.TabIndex = 83;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(662, 46);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(92, 17);
            this.label74.TabIndex = 82;
            this.label74.Text = "Shower Hose";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(576, 43);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(45, 17);
            this.label80.TabIndex = 76;
            this.label80.Text = "Spout";
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(550, 98);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(100, 22);
            this.textBox67.TabIndex = 73;
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(550, 70);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(100, 22);
            this.textBox68.TabIndex = 72;
            // 
            // textBox71
            // 
            this.textBox71.Location = new System.Drawing.Point(444, 98);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(100, 22);
            this.textBox71.TabIndex = 64;
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(444, 70);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(100, 22);
            this.textBox72.TabIndex = 63;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(441, 43);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(95, 17);
            this.label86.TabIndex = 62;
            this.label86.Text = "Chrome Head";
            // 
            // textBox75
            // 
            this.textBox75.Location = new System.Drawing.Point(338, 98);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(100, 22);
            this.textBox75.TabIndex = 54;
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(338, 70);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(100, 22);
            this.textBox76.TabIndex = 53;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(346, 43);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(70, 17);
            this.label92.TabIndex = 52;
            this.label92.Text = "Pillar TAP";
            // 
            // textBox79
            // 
            this.textBox79.Location = new System.Drawing.Point(232, 98);
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(100, 22);
            this.textBox79.TabIndex = 43;
            // 
            // textBox80
            // 
            this.textBox80.Location = new System.Drawing.Point(232, 70);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(100, 22);
            this.textBox80.TabIndex = 42;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(247, 43);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(75, 17);
            this.label98.TabIndex = 41;
            this.label98.Text = "Brass TAP";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(137, 43);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(60, 17);
            this.label104.TabIndex = 35;
            this.label104.Text = "BIP TAP";
            // 
            // textBox83
            // 
            this.textBox83.Location = new System.Drawing.Point(126, 98);
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(100, 22);
            this.textBox83.TabIndex = 32;
            // 
            // textBox84
            // 
            this.textBox84.Location = new System.Drawing.Point(126, 70);
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(100, 22);
            this.textBox84.TabIndex = 31;
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(43, 103);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(50, 17);
            this.label107.TabIndex = 28;
            this.label107.Text = "20 mm";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(43, 75);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(50, 17);
            this.label108.TabIndex = 27;
            this.label108.Text = "15 mm";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label63);
            this.groupBox3.Controls.Add(this.label64);
            this.groupBox3.Controls.Add(this.label65);
            this.groupBox3.Controls.Add(this.label66);
            this.groupBox3.Controls.Add(this.label67);
            this.groupBox3.Controls.Add(this.label62);
            this.groupBox3.Controls.Add(this.textBox53);
            this.groupBox3.Controls.Add(this.textBox54);
            this.groupBox3.Controls.Add(this.textBox55);
            this.groupBox3.Controls.Add(this.textBox56);
            this.groupBox3.Controls.Add(this.label58);
            this.groupBox3.Controls.Add(this.label59);
            this.groupBox3.Controls.Add(this.label60);
            this.groupBox3.Controls.Add(this.label61);
            this.groupBox3.Location = new System.Drawing.Point(868, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(428, 332);
            this.groupBox3.TabIndex = 41;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Plasson Fittings ";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(302, 215);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(46, 17);
            this.label63.TabIndex = 96;
            this.label63.Text = "32x50";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(302, 168);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(46, 17);
            this.label64.TabIndex = 95;
            this.label64.Text = "25x32";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(302, 126);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(46, 17);
            this.label65.TabIndex = 94;
            this.label65.Text = "20x25";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(302, 89);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(46, 17);
            this.label66.TabIndex = 93;
            this.label66.Text = "15x20";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(302, 46);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(35, 17);
            this.label67.TabIndex = 92;
            this.label67.Text = "Size";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(143, 46);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(116, 17);
            this.label62.TabIndex = 40;
            this.label62.Text = "Couple Reducing";
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(146, 215);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(100, 22);
            this.textBox53.TabIndex = 39;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(146, 168);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(100, 22);
            this.textBox54.TabIndex = 38;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(146, 126);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(100, 22);
            this.textBox55.TabIndex = 37;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(146, 86);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(100, 22);
            this.textBox56.TabIndex = 36;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(63, 215);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(50, 17);
            this.label58.TabIndex = 34;
            this.label58.Text = "32 mm";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(63, 168);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(50, 17);
            this.label59.TabIndex = 33;
            this.label59.Text = "25 mm";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(63, 131);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(50, 17);
            this.label60.TabIndex = 32;
            this.label60.Text = "20 mm";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(63, 89);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(50, 17);
            this.label61.TabIndex = 31;
            this.label61.Text = "15 mm";
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.label45);
            this.groupBox23.Controls.Add(this.label46);
            this.groupBox23.Controls.Add(this.label47);
            this.groupBox23.Controls.Add(this.textBox37);
            this.groupBox23.Controls.Add(this.textBox38);
            this.groupBox23.Controls.Add(this.textBox39);
            this.groupBox23.Controls.Add(this.textBox40);
            this.groupBox23.Controls.Add(this.textBox41);
            this.groupBox23.Controls.Add(this.textBox42);
            this.groupBox23.Controls.Add(this.label48);
            this.groupBox23.Controls.Add(this.label49);
            this.groupBox23.Location = new System.Drawing.Point(467, 6);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(395, 332);
            this.groupBox23.TabIndex = 14;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "2.3 Copsal Fittings";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(70, 104);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(45, 17);
            this.label45.TabIndex = 28;
            this.label45.Text = "Elbow";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(70, 74);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(35, 17);
            this.label46.TabIndex = 27;
            this.label46.Text = "TEE";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(70, 136);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(51, 17);
            this.label47.TabIndex = 26;
            this.label47.Text = "Socket";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(264, 127);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(100, 22);
            this.textBox37.TabIndex = 19;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(151, 127);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(100, 22);
            this.textBox38.TabIndex = 18;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(264, 99);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(100, 22);
            this.textBox39.TabIndex = 17;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(151, 99);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(100, 22);
            this.textBox40.TabIndex = 16;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(264, 71);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(100, 22);
            this.textBox41.TabIndex = 15;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(151, 71);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(100, 22);
            this.textBox42.TabIndex = 14;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(266, 42);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(89, 17);
            this.label48.TabIndex = 13;
            this.label48.Text = "Size : 20 mm";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(148, 42);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(89, 17);
            this.label49.TabIndex = 12;
            this.label49.Text = "Size : 15 mm";
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.label3);
            this.groupBox22.Controls.Add(this.textBox12);
            this.groupBox22.Controls.Add(this.textBox9);
            this.groupBox22.Controls.Add(this.label2);
            this.groupBox22.Controls.Add(this.label1);
            this.groupBox22.Controls.Add(this.textBox8);
            this.groupBox22.Controls.Add(this.textBox7);
            this.groupBox22.Controls.Add(this.textBox6);
            this.groupBox22.Controls.Add(this.textBox1);
            this.groupBox22.Controls.Add(this.label41);
            this.groupBox22.Controls.Add(this.label40);
            this.groupBox22.Controls.Add(this.label39);
            this.groupBox22.Controls.Add(this.label38);
            this.groupBox22.Controls.Add(this.label37);
            this.groupBox22.Controls.Add(this.label36);
            this.groupBox22.Controls.Add(this.textBox19);
            this.groupBox22.Controls.Add(this.textBox18);
            this.groupBox22.Controls.Add(this.textBox17);
            this.groupBox22.Controls.Add(this.textBox16);
            this.groupBox22.Controls.Add(this.textBox15);
            this.groupBox22.Controls.Add(this.textBox14);
            this.groupBox22.Controls.Add(this.textBox11);
            this.groupBox22.Controls.Add(this.textBox10);
            this.groupBox22.Controls.Add(this.textBox5);
            this.groupBox22.Controls.Add(this.textBox4);
            this.groupBox22.Controls.Add(this.textBox3);
            this.groupBox22.Controls.Add(this.textBox2);
            this.groupBox22.Controls.Add(this.label35);
            this.groupBox22.Controls.Add(this.label34);
            this.groupBox22.Location = new System.Drawing.Point(6, 6);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(455, 332);
            this.groupBox22.TabIndex = 13;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Conex Fittings";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 295);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 17);
            this.label3.TabIndex = 38;
            this.label3.Text = "Socket";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(300, 295);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 22);
            this.textBox12.TabIndex = 37;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(194, 295);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 22);
            this.textBox9.TabIndex = 36;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 267);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 17);
            this.label2.TabIndex = 35;
            this.label2.Text = "Nipple";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 242);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 17);
            this.label1.TabIndex = 34;
            this.label1.Text = "PLUG";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(300, 267);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 22);
            this.textBox8.TabIndex = 33;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(194, 267);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 22);
            this.textBox7.TabIndex = 32;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(300, 239);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 22);
            this.textBox6.TabIndex = 31;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(194, 239);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 30;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(29, 216);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(70, 17);
            this.label41.TabIndex = 21;
            this.label41.Text = "Copr Pipe";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(29, 188);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(109, 17);
            this.label40.TabIndex = 13;
            this.label40.Text = "Adapter-Female";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(29, 160);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(93, 17);
            this.label39.TabIndex = 29;
            this.label39.Text = "Adapter-Male";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(29, 132);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(63, 17);
            this.label38.TabIndex = 28;
            this.label38.Text = "Coupling";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(29, 104);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(58, 17);
            this.label37.TabIndex = 27;
            this.label37.Text = "ELBOW";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(29, 74);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(35, 17);
            this.label36.TabIndex = 26;
            this.label36.Text = "TEE";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(300, 211);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(100, 22);
            this.textBox19.TabIndex = 25;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(194, 211);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(100, 22);
            this.textBox18.TabIndex = 24;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(300, 183);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(100, 22);
            this.textBox17.TabIndex = 23;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(194, 183);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 22);
            this.textBox16.TabIndex = 22;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(300, 155);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 22);
            this.textBox15.TabIndex = 21;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(194, 155);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 22);
            this.textBox14.TabIndex = 20;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(300, 129);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 22);
            this.textBox11.TabIndex = 19;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(194, 127);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 22);
            this.textBox10.TabIndex = 18;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(300, 99);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 22);
            this.textBox5.TabIndex = 17;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(194, 99);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 22);
            this.textBox4.TabIndex = 16;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(300, 71);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 15;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(194, 71);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 14;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(297, 42);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(89, 17);
            this.label35.TabIndex = 13;
            this.label35.Text = "Size : 20 mm";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(191, 42);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(89, 17);
            this.label34.TabIndex = 12;
            this.label34.Text = "Size : 15 mm";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button5);
            this.tabPage3.Controls.Add(this.dataGridView1);
            this.tabPage3.Controls.Add(this.groupBox36);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1909, 748);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Upload Documents ";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(924, 464);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(177, 43);
            this.button5.TabIndex = 2;
            this.button5.Text = "Save Files";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(8, 120);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1093, 338);
            this.dataGridView1.TabIndex = 1;
            // 
            // groupBox36
            // 
            this.groupBox36.Controls.Add(this.button4);
            this.groupBox36.Controls.Add(this.button3);
            this.groupBox36.Controls.Add(this.textBox141);
            this.groupBox36.Controls.Add(this.label146);
            this.groupBox36.Location = new System.Drawing.Point(8, 15);
            this.groupBox36.Name = "groupBox36";
            this.groupBox36.Size = new System.Drawing.Size(313, 99);
            this.groupBox36.TabIndex = 0;
            this.groupBox36.TabStop = false;
            this.groupBox36.Text = "Upload Document";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(217, 49);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(82, 31);
            this.button4.TabIndex = 2;
            this.button4.Text = "Upload";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(129, 49);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(82, 31);
            this.button3.TabIndex = 1;
            this.button3.Text = "Choose File";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox141
            // 
            this.textBox141.Location = new System.Drawing.Point(129, 23);
            this.textBox141.Name = "textBox141";
            this.textBox141.Size = new System.Drawing.Size(170, 22);
            this.textBox141.TabIndex = 1;
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.Location = new System.Drawing.Point(6, 26);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(117, 17);
            this.label146.TabIndex = 0;
            this.label146.Text = "Document Name ";
            // 
            // groupBox29
            // 
            this.groupBox29.BackColor = System.Drawing.Color.White;
            this.groupBox29.Controls.Add(this.groupBox35);
            this.groupBox29.Controls.Add(this.groupBox34);
            this.groupBox29.Controls.Add(this.groupBox33);
            this.groupBox29.Controls.Add(this.groupBox32);
            this.groupBox29.Controls.Add(this.groupBox31);
            this.groupBox29.Controls.Add(this.groupBox30);
            this.groupBox29.Controls.Add(this.pictureBox1);
            this.groupBox29.Controls.Add(this.label141);
            this.groupBox29.Location = new System.Drawing.Point(0, 31);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Size = new System.Drawing.Size(1917, 120);
            this.groupBox29.TabIndex = 3;
            this.groupBox29.TabStop = false;
            this.groupBox29.Text = "Survey Assessment";
            // 
            // groupBox35
            // 
            this.groupBox35.Controls.Add(this.dateTimePicker1);
            this.groupBox35.Controls.Add(this.checkBox2);
            this.groupBox35.Controls.Add(this.label144);
            this.groupBox35.Controls.Add(this.label145);
            this.groupBox35.Location = new System.Drawing.Point(1173, 23);
            this.groupBox35.Name = "groupBox35";
            this.groupBox35.Size = new System.Drawing.Size(336, 83);
            this.groupBox35.TabIndex = 13;
            this.groupBox35.TabStop = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(136, 19);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(186, 22);
            this.dateTimePicker1.TabIndex = 14;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(217, 54);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(18, 17);
            this.checkBox2.TabIndex = 9;
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Location = new System.Drawing.Point(6, 59);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(109, 17);
            this.label144.TabIndex = 10;
            this.label144.Text = "Contract Signed";
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.Location = new System.Drawing.Point(6, 18);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(118, 17);
            this.label145.TabIndex = 9;
            this.label145.Text = "Assessment Date";
            // 
            // groupBox34
            // 
            this.groupBox34.Controls.Add(this.comboBox1);
            this.groupBox34.Location = new System.Drawing.Point(928, 23);
            this.groupBox34.Name = "groupBox34";
            this.groupBox34.Size = new System.Drawing.Size(239, 82);
            this.groupBox34.TabIndex = 12;
            this.groupBox34.TabStop = false;
            this.groupBox34.Text = "SMME";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(23, 32);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(188, 24);
            this.comboBox1.TabIndex = 13;
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.textBox140);
            this.groupBox33.Location = new System.Drawing.Point(722, 22);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Size = new System.Drawing.Size(200, 82);
            this.groupBox33.TabIndex = 11;
            this.groupBox33.TabStop = false;
            this.groupBox33.Text = "Consortium";
            // 
            // textBox140
            // 
            this.textBox140.Location = new System.Drawing.Point(11, 21);
            this.textBox140.Multiline = true;
            this.textBox140.Name = "textBox140";
            this.textBox140.Size = new System.Drawing.Size(175, 50);
            this.textBox140.TabIndex = 10;
            // 
            // groupBox32
            // 
            this.groupBox32.Controls.Add(this.textBox139);
            this.groupBox32.Location = new System.Drawing.Point(516, 21);
            this.groupBox32.Name = "groupBox32";
            this.groupBox32.Size = new System.Drawing.Size(200, 82);
            this.groupBox32.TabIndex = 10;
            this.groupBox32.TabStop = false;
            this.groupBox32.Text = "Suburb";
            // 
            // textBox139
            // 
            this.textBox139.Location = new System.Drawing.Point(11, 21);
            this.textBox139.Multiline = true;
            this.textBox139.Name = "textBox139";
            this.textBox139.Size = new System.Drawing.Size(175, 50);
            this.textBox139.TabIndex = 10;
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.textBox138);
            this.groupBox31.Location = new System.Drawing.Point(307, 23);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(200, 82);
            this.groupBox31.TabIndex = 9;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "Township";
            // 
            // textBox138
            // 
            this.textBox138.Location = new System.Drawing.Point(11, 21);
            this.textBox138.Multiline = true;
            this.textBox138.Name = "textBox138";
            this.textBox138.Size = new System.Drawing.Size(175, 50);
            this.textBox138.TabIndex = 10;
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.checkBox1);
            this.groupBox30.Controls.Add(this.label143);
            this.groupBox30.Controls.Add(this.textBox137);
            this.groupBox30.Controls.Add(this.label142);
            this.groupBox30.Location = new System.Drawing.Point(67, 22);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(234, 83);
            this.groupBox30.TabIndex = 8;
            this.groupBox30.TabStop = false;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(153, 55);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(18, 17);
            this.checkBox1.TabIndex = 9;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Location = new System.Drawing.Point(6, 59);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(89, 17);
            this.label143.TabIndex = 10;
            this.label143.Text = "J/W Approve";
            // 
            // textBox137
            // 
            this.textBox137.Location = new System.Drawing.Point(122, 18);
            this.textBox137.Name = "textBox137";
            this.textBox137.Size = new System.Drawing.Size(94, 22);
            this.textBox137.TabIndex = 9;
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Location = new System.Drawing.Point(6, 18);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(81, 17);
            this.label142.TabIndex = 9;
            this.label142.Text = "Jobcard No";
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label141.Location = new System.Drawing.Point(700, 0);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(0, 44);
            this.label141.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.surveysToolStripMenuItem,
            this.jobsToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.sMMESToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1929, 28);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // surveysToolStripMenuItem
            // 
            this.surveysToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.captureSurveyToolStripMenuItem,
            this.viewSurveysToolStripMenuItem});
            this.surveysToolStripMenuItem.Name = "surveysToolStripMenuItem";
            this.surveysToolStripMenuItem.Size = new System.Drawing.Size(76, 24);
            this.surveysToolStripMenuItem.Text = "Surveys ";
            this.surveysToolStripMenuItem.Click += new System.EventHandler(this.surveysToolStripMenuItem_Click);
            // 
            // captureSurveyToolStripMenuItem
            // 
            this.captureSurveyToolStripMenuItem.Name = "captureSurveyToolStripMenuItem";
            this.captureSurveyToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.captureSurveyToolStripMenuItem.Text = "Survey Sheet";
            // 
            // viewSurveysToolStripMenuItem
            // 
            this.viewSurveysToolStripMenuItem.Name = "viewSurveysToolStripMenuItem";
            this.viewSurveysToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.viewSurveysToolStripMenuItem.Text = "View Surveys";
            this.viewSurveysToolStripMenuItem.Click += new System.EventHandler(this.viewSurveysToolStripMenuItem_Click);
            // 
            // jobsToolStripMenuItem
            // 
            this.jobsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewJobCardsToolStripMenuItem,
            this.updateJobCardToolStripMenuItem});
            this.jobsToolStripMenuItem.Name = "jobsToolStripMenuItem";
            this.jobsToolStripMenuItem.Size = new System.Drawing.Size(56, 24);
            this.jobsToolStripMenuItem.Text = "Jobs ";
            // 
            // viewJobCardsToolStripMenuItem
            // 
            this.viewJobCardsToolStripMenuItem.Name = "viewJobCardsToolStripMenuItem";
            this.viewJobCardsToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.viewJobCardsToolStripMenuItem.Text = "View Job Cards";
            this.viewJobCardsToolStripMenuItem.Click += new System.EventHandler(this.viewJobCardsToolStripMenuItem_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1669, 940);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(244, 36);
            this.button1.TabIndex = 17;
            this.button1.Text = "Save Assesment";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.surveyReportsToolStripMenuItem,
            this.jobCardReportsToolStripMenuItem,
            this.sMMEReportsToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(74, 24);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // sMMESToolStripMenuItem
            // 
            this.sMMESToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewSMMEToolStripMenuItem,
            this.viewSMMESToolStripMenuItem,
            this.updateSMMEToolStripMenuItem});
            this.sMMESToolStripMenuItem.Name = "sMMESToolStripMenuItem";
            this.sMMESToolStripMenuItem.Size = new System.Drawing.Size(76, 24);
            this.sMMESToolStripMenuItem.Text = "SMME\'S";
            // 
            // surveyReportsToolStripMenuItem
            // 
            this.surveyReportsToolStripMenuItem.Name = "surveyReportsToolStripMenuItem";
            this.surveyReportsToolStripMenuItem.Size = new System.Drawing.Size(205, 26);
            this.surveyReportsToolStripMenuItem.Text = "Survey Reports";
            // 
            // jobCardReportsToolStripMenuItem
            // 
            this.jobCardReportsToolStripMenuItem.Name = "jobCardReportsToolStripMenuItem";
            this.jobCardReportsToolStripMenuItem.Size = new System.Drawing.Size(205, 26);
            this.jobCardReportsToolStripMenuItem.Text = "Job Card Reports";
            // 
            // sMMEReportsToolStripMenuItem
            // 
            this.sMMEReportsToolStripMenuItem.Name = "sMMEReportsToolStripMenuItem";
            this.sMMEReportsToolStripMenuItem.Size = new System.Drawing.Size(205, 26);
            this.sMMEReportsToolStripMenuItem.Text = "SMME Reports";
            // 
            // addNewSMMEToolStripMenuItem
            // 
            this.addNewSMMEToolStripMenuItem.Name = "addNewSMMEToolStripMenuItem";
            this.addNewSMMEToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.addNewSMMEToolStripMenuItem.Text = "Add New SMME";
            // 
            // viewSMMESToolStripMenuItem
            // 
            this.viewSMMESToolStripMenuItem.Name = "viewSMMESToolStripMenuItem";
            this.viewSMMESToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.viewSMMESToolStripMenuItem.Text = "View SMME\'S";
            this.viewSMMESToolStripMenuItem.Click += new System.EventHandler(this.viewSMMESToolStripMenuItem_Click);
            // 
            // updateSMMEToolStripMenuItem
            // 
            this.updateSMMEToolStripMenuItem.Name = "updateSMMEToolStripMenuItem";
            this.updateSMMEToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.updateSMMEToolStripMenuItem.Text = "Update SMME ";
            // 
            // updateJobCardToolStripMenuItem
            // 
            this.updateJobCardToolStripMenuItem.Name = "updateJobCardToolStripMenuItem";
            this.updateJobCardToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.updateJobCardToolStripMenuItem.Text = "Update Job Card";
            this.updateJobCardToolStripMenuItem.Click += new System.EventHandler(this.updateJobCardToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Job.Properties.Resources.logo_otec;
            this.pictureBox1.Location = new System.Drawing.Point(1653, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(212, 88);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // HomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1929, 1014);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.groupBox29);
            this.Controls.Add(this.tabControl1);
            this.Name = "HomeForm";
            this.Text = "Survey Assessment ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.HomeForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox28.ResumeLayout(false);
            this.groupBox28.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.Size.ResumeLayout(false);
            this.Size.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox36.ResumeLayout(false);
            this.groupBox36.PerformLayout();
            this.groupBox29.ResumeLayout(false);
            this.groupBox29.PerformLayout();
            this.groupBox35.ResumeLayout(false);
            this.groupBox35.PerformLayout();
            this.groupBox34.ResumeLayout(false);
            this.groupBox33.ResumeLayout(false);
            this.groupBox33.PerformLayout();
            this.groupBox32.ResumeLayout(false);
            this.groupBox32.PerformLayout();
            this.groupBox31.ResumeLayout(false);
            this.groupBox31.PerformLayout();
            this.groupBox30.ResumeLayout(false);
            this.groupBox30.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox textBox92;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.TextBox textBox93;
        private System.Windows.Forms.TextBox textBox94;
        private System.Windows.Forms.TextBox textBox95;
        private System.Windows.Forms.TextBox textBox96;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.TextBox textBox97;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox textBox98;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.TextBox textBox99;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.TextBox textBox100;
        private System.Windows.Forms.TextBox textBox101;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.TextBox textBox102;
        private System.Windows.Forms.TextBox textBox103;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox textBox104;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.GroupBox Size;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox textBox105;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.TextBox textBox106;
        private System.Windows.Forms.TextBox textBox107;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.TextBox textBox108;
        private System.Windows.Forms.TextBox textBox109;
        private System.Windows.Forms.TextBox textBox110;
        private System.Windows.Forms.TextBox textBox111;
        private System.Windows.Forms.TextBox textBox112;
        private System.Windows.Forms.TextBox textBox113;
        private System.Windows.Forms.TextBox textBox114;
        private System.Windows.Forms.TextBox textBox115;
        private System.Windows.Forms.TextBox textBox116;
        private System.Windows.Forms.TextBox textBox117;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.TextBox textBox118;
        private System.Windows.Forms.TextBox textBox119;
        private System.Windows.Forms.TextBox textBox120;
        private System.Windows.Forms.TextBox textBox121;
        private System.Windows.Forms.TextBox textBox122;
        private System.Windows.Forms.TextBox textBox123;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.TextBox textBox124;
        private System.Windows.Forms.TextBox textBox125;
        private System.Windows.Forms.TextBox textBox126;
        private System.Windows.Forms.TextBox textBox127;
        private System.Windows.Forms.TextBox textBox128;
        private System.Windows.Forms.TextBox textBox129;
        private System.Windows.Forms.TextBox textBox130;
        private System.Windows.Forms.TextBox textBox131;
        private System.Windows.Forms.TextBox textBox132;
        private System.Windows.Forms.TextBox textBox133;
        private System.Windows.Forms.TextBox textBox134;
        private System.Windows.Forms.TextBox textBox135;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.TextBox textBox136;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem surveysToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem captureSurveyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewSurveysToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jobsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewJobCardsToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.TextBox textBox137;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.GroupBox groupBox35;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.GroupBox groupBox34;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.TextBox textBox140;
        private System.Windows.Forms.GroupBox groupBox32;
        private System.Windows.Forms.TextBox textBox139;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.TextBox textBox138;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox36;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox141;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem surveyReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jobCardReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sMMEReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sMMESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewSMMEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewSMMESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateSMMEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateJobCardToolStripMenuItem;
    }
}