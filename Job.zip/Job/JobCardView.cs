﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Job
{
    public partial class JobCardView : Form
    {
        public JobCardView()
        {
            InitializeComponent();
        }

        private void captureSurveyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form homeform = new HomeForm();
            homeform.ShowDialog();
            this.Close();
        }

        private void viewSurveysToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form surveyView = new SurveyView();
            surveyView.ShowDialog();
            this.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void viewJobCardsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void updateJobCardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form jobCardUpdate = new Job_Update();
            jobCardUpdate.ShowDialog();
            this.Close();
        }
    }
}
